<?php
// Buat koneksi ke database
$koneksi = new mysqli("localhost", "root", "", "restoran");

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Pastikan ID pelanggan ada dalam URL
if(isset($_GET['id'])) {
    $idPelanggan = $_GET['id'];

    // Buat query SQL untuk menghapus data pelanggan dari tabel
    $hapusQuery = "DELETE FROM pelanggan WHERE idPelanggan = $idPelanggan";

    if ($koneksi->query($hapusQuery) === TRUE) {
        echo "Data pelanggan berhasil dihapus dari database.";
    } else {
        echo "Error: " . $hapusQuery . "<br>" . $koneksi->error;
    }

    // Reset auto-increment setelah menghapus data
    $resetQuery = "ALTER TABLE pelanggan AUTO_INCREMENT = 1";
    if ($koneksi->query($resetQuery) === TRUE) {
        echo "Auto-increment berhasil direset.";
    } else {
        echo "Error: " . $resetQuery . "<br>" . $koneksi->error;
    }
} else {
    echo "ID pelanggan tidak ditemukan.";
}

// Tutup koneksi
$koneksi->close();

// Redirect kembali ke halaman utama setelah penghapusan
header("Location: entripelanggan.php");
exit();
?>
