<!--Proses Tambah Pelanggan -->

<?php
// Include file koneksi.php
include '..\koneksi.php';

// Mengecek apakah form telah di-submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil nilai input dari form
    $nmPelanggan = $_POST['nmPelanggan'];
    $jk = $_POST['jk'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $no_meja = $_POST['no_meja'];

    // Membuka koneksi ke database
    $koneksi = mysqli_connect("localhost", "root", "", "restoran");

    // Mengecek apakah koneksi berhasil
    if (!$koneksi) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Query untuk menyimpan data ke database
    $query = "INSERT INTO pelanggan (nmPelanggan, jk, no_hp, alamat, no_meja) VALUES ('$nmPelanggan', '$jk', '$no_hp', '$alamat', '$no_meja')";

    // Eksekusi query dan periksa apakah berhasil
    if (mysqli_query($koneksi, $query)) {
        // Jika berhasil, redirect ke halaman entrimeja.php
        header("Location: entripelanggan.php");
        exit();
    } else {
        // Jika terjadi kesalahan, tampilkan pesan error
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }

    // Menutup koneksi database
    mysqli_close($koneksi);
}
?>
