<?php
// Pastikan form telah dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Periksa apakah semua input diterima
    if(isset($_POST['nama_menu']) && isset($_POST['harga'])) {
        // Ambil data dari formulir
        $nama_menu = $_POST['nama_menu'];
        $harga = $_POST['harga'];

        // Lakukan koneksi ke database
        $koneksi = new mysqli("localhost", "root", "", "restoran");

        // Periksa koneksi
        if ($koneksi->connect_error) {
            die("Koneksi gagal: " . $koneksi->connect_error);
        }

        // Siapkan statement SQL untuk menyisipkan data
        $sql = "INSERT INTO menu (namamenu, harga) VALUES (?, ?)";
        $statement = $koneksi->prepare($sql);

        // Bind parameter ke statement
        $statement->bind_param("si", $nama_menu, $harga);

        // Eksekusi statement
        if ($statement->execute()) {
            // Jika berhasil, redirect ke halaman utama atau tampilkan pesan sukses
            header("Location: entribarang.php"); // Ganti index.php dengan halaman utama Anda
            exit();
        } else {
            // Jika gagal, tampilkan pesan error
            echo "Error: " . $sql . "<br>" . $koneksi->error;
        }

        // Tutup statement dan koneksi
        $statement->close();
        $koneksi->close();
    } else {
        echo "Semua input harus diisi!";
    }
} else {
    // Jika tidak, redirect ke halaman tambah menu
    header("Location: tambahmenu.php"); // Ganti tambahbarang.php dengan halaman tambah menu Anda
    exit();
}
?>
