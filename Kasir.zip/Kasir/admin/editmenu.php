<?php
include '..\koneksi.php';

// Pastikan variabel $_GET['id'] telah didefinisikan dan tidak kosong
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Ambil ID Pelanggan dari URL
    $id_menu = $_GET['id'];

    // Membuka koneksi ke database
    $koneksi = mysqli_connect("localhost", "root", "", "restoran");

    // Mengecek apakah koneksi berhasil
    if (!$koneksi) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Query untuk mengambil data pelanggan berdasarkan ID
    $query = "SELECT * FROM menu WHERE id_menu = $id_menu";
    $result = mysqli_query($koneksi, $query);

    // Periksa apakah query berhasil dieksekusi
    if ($result) {
        // Ambil data pelanggan
        $data = mysqli_fetch_assoc($result);

        // Masukkan data ke dalam variabel
        $nama_menu = $data['namamenu'];

        $harga = $data['harga'];
    } else {
        echo "Gagal mengambil data pelanggan: " . mysqli_error($koneksi);
    }

    // Menutup koneksi database
    mysqli_close($koneksi);
} else {
    echo "ID Menu tidak ditemukan dalam URL.";
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Kasir Go - Edit Menu</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        /* Add your custom styles here */
    </style>
</head>

<body id="page-top">
    <?php include 'template/sidebar.php'; ?>
    <?php include 'template/navbar.php'; ?>

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- Add your content here -->
            <!-- Form untuk Edit Menu -->
            <div class="container form-container">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <form action="proses_edit_menu.php" method="post">
                            <input type="hidden" name="id_menu" value="<?php echo $id_menu; ?>"> <!-- Input hidden untuk menyimpan ID menu yang akan diubah -->
                            <div class="form-group">
                                <label for="nama_menu">Nama Menu</label>
                                <input type="text" class="form-control" id="nama_menu" name="nama_menu" value="<?php echo $nama_menu; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="harga">Harga</label>
                                <input type="text" class="form-control" id="harga" name="harga" value="<?php echo $harga; ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="entribarang.php" class="btn btn-secondary">Batal</a> <!-- Tambahkan button batal -->
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add your footer here -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="text-center">
                    <span>Copyright &copy; 2024 Kasir Go - All rights reserved.</span>
                </div>
            </div>
        </footer>
    </div>

    <!-- Add your scripts here -->
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>
</body>

</html>
