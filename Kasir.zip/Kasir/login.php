<?php
session_start(); // Mulai sesi

include 'koneksi.php';

$user = $_POST['username'];
$pass = $_POST['password']; // Tidak perlu menggunakan MD5 lagi

$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$user' AND password='$pass'");

$cek = mysqli_num_rows($sql);

if($cek > 0){
    $data = mysqli_fetch_assoc($sql);
    if($data['level']=="admin") {
        $_SESSION['username'] = $user;
        $_SESSION['level'] = "admin";
        header("location: admin/dashboard.php");
    } elseif($data['level']=="waiter") {
        $_SESSION['username'] = $user;
        $_SESSION['level'] = "waiter";
        header("location: waiter/dashboard.php");
    } else {
        header("location: index.php?pesan=gagal");
    }	
} else {
    header("location: index.php?pesan=gagal");
}
?>
