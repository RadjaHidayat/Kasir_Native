<?php
// Pastikan ID pesanan ada dalam URL
if(isset($_GET['id'])) {
    // Sanitasi ID pesanan
    $id_pesanan = $_GET['id'];

    // Buat koneksi ke database
    $koneksi = new mysqli("localhost", "root", "", "restoran");

    // Periksa koneksi
    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }

    // Buat query SQL untuk menghapus data pesanan dari tabel
    $query = "DELETE FROM pesanan WHERE id_pesanan = ?";
    $statement = $koneksi->prepare($query);

    // Bind parameter ke statement
    $statement->bind_param("i", $id_pesanan);

    // Eksekusi statement
    if ($statement->execute()) {
        // Buat query SQL untuk mengatur ulang nilai auto-increment
        $resetQuery = "ALTER TABLE pesanan AUTO_INCREMENT = 1";
        if ($koneksi->query($resetQuery) === TRUE) {
            // Redirect kembali ke halaman utama setelah penghapusan
            header("Location: entriorder.php"); // Ganti entriorder.php dengan halaman utama Anda
            exit();
        } else {
            echo "Error: " . $resetQuery . "<br>" . $koneksi->error;
        }
    } else {
        echo "Error: " . $query . "<br>" . $koneksi->error;
    }

    // Tutup statement dan koneksi
    $statement->close();
    $koneksi->close();
} else {
    echo "ID pesanan tidak ditemukan.";
}
?>
