<?php
// Periksa apakah form telah dikirimkan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data yang dikirimkan melalui form
    $id_menu = $_POST["menu"];
    $idPelanggan = $_POST["pelanggan"];
    $jumlah = $_POST["jumlah"];
    $id = $_POST["user"];

    // Lakukan validasi data
    if (empty($id_menu) || empty($idPelanggan) || empty($jumlah) || empty($id)) {
        // Jika ada data yang kosong, redirect kembali ke halaman form dengan pesan error
        header("location: entriorder.php?error=Data tidak lengkap");
        exit();
    } else {
        // Buat koneksi ke database
        $koneksi = new mysqli("localhost", "root", "", "restoran");

        // Periksa koneksi
        if ($koneksi->connect_error) {
            die("Koneksi gagal: " . $koneksi->connect_error);
        }

        // Escape string untuk mencegah SQL injection
        $id_menu = $koneksi->real_escape_string($id_menu);
        $idPelanggan = $koneksi->real_escape_string($idPelanggan);
        $jumlah = $koneksi->real_escape_string($jumlah);
        $id = $koneksi->real_escape_string($id);

        // Query SQL untuk menambahkan pesanan ke database
        $sql = "INSERT INTO pesanan (id_menu, idPelanggan, jumlah, id) VALUES ('$id_menu', '$idPelanggan', '$jumlah', '$id')";

        // Jalankan query
        if ($koneksi->query($sql) === TRUE) {
            // Jika query berhasil dijalankan, redirect ke halaman entriorder.php dengan pesan sukses
            header("location: entriorder.php?success=Pesanan berhasil ditambahkan");
            exit();
        } else {
            // Jika query gagal dijalankan, redirect kembali ke halaman form dengan pesan error
            header("location: entriorder.php?error=Error: " . $koneksi->error);
            exit();
        }

        // Tutup koneksi
        $koneksi->close();
    }
} else {
    // Jika halaman ini diakses langsung tanpa melalui form, redirect ke halaman form
    header("location: entriorder.php");
    exit();
}
?>
