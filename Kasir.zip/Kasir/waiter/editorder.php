<?php
include '../koneksi.php'; // Perhatikan penyesuaian lokasi file koneksi.php

// Pastikan ID pesanan ada dalam URL
if (isset($_GET['id'])) {
    // Sanitasi ID pesanan
    $id_pesanan = htmlspecialchars($_GET['id']); // Disarankan menggunakan htmlspecialchars untuk mencegah XSS

    // Buat query SQL untuk mengambil data pesanan dari tabel
    $query = "SELECT p.*, m.namamenu, m.id_menu FROM pesanan p JOIN menu m ON p.id_menu = m.id_menu WHERE id_pesanan = ?";
    $statement = $koneksi->prepare($query);

    // Bind parameter ke statement
    $statement->bind_param("i", $id_pesanan);

    // Eksekusi statement
    if ($statement->execute()) {
        // Ambil data pesanan
        $result = $statement->get_result();
        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();

            // Masukkan data ke dalam variabel
            $id_menu = $data['id_menu'];
            $nama_menu = $data['namamenu'];
            $jumlah = $data['jumlah'];
        } else {
            die("ID pesanan tidak ditemukan."); // Berhenti eksekusi skrip jika ID pesanan tidak ditemukan
        }
    } else {
        die("Error: " . $query . "<br>" . $koneksi->error); // Tampilkan pesan kesalahan jika eksekusi query gagal
    }

    // Tutup statement
    $statement->close();
} else {
    die("ID pesanan tidak ditemukan."); // Tampilkan pesan kesalahan jika ID pesanan tidak tersedia dalam URL
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Kasir Go - Edit Pesanan</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        /* Add your custom styles here */
    </style>
</head>

<body id="page-top">
    <?php include 'template/sidebar.php'; ?>
    <?php include 'template/navbar.php'; ?>

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- Add your content here -->
            <!-- Form untuk Edit Pesanan -->
            <div class="container form-container">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <form action="proses_edit_order.php" method="post">
                            <div class="form-group">
                                <label for="menu">ID Menu</label>
                                <select class="form-control" id="menu" name="menu" required>
                                    <?php
                                    // Ambil data dari tabel menu
                                    $query_menu = "SELECT id_menu, namamenu FROM menu";
                                    $result_menu = mysqli_query($koneksi, $query_menu);

                                    // Periksa apakah query berhasil dieksekusi
                                    if ($result_menu && mysqli_num_rows($result_menu) > 0) {
                                        // Tampilkan data dalam dropdown/select box
                                        while ($row_menu = mysqli_fetch_assoc($result_menu)) {
                                            $selected = ($row_menu['id_menu'] == $id_menu) ? 'selected' : '';
                                            echo '<option value="' . $row_menu['id_menu'] . '" ' . $selected . '>' . $row_menu['namamenu'] . '</option>';
                                        }
                                    } else {
                                        echo "<option value='' disabled selected>Tidak ada menu tersedia</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="jumlah">Jumlah</label>
                                <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo $jumlah; ?>" required>
                            </div>

                            <!-- Hidden input for ID Pesanan -->
                            <input type="hidden" name="id_pesanan" value="<?php echo $id_pesanan; ?>">

                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="entriorder.php" class="btn btn-secondary">Batal</a> <!-- Tambahkan button batal -->
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add your footer here -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="text-center">
                    <span>Copyright &copy; 2024 Kasir Go - All rights reserved.</span>
                </div>
            </div>
        </footer>
    </div>

    <!-- Add your scripts here -->
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>
</body>

</html>
